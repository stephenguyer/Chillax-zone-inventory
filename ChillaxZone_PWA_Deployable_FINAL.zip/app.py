from flask import Flask, render_template, request, redirect, url_for
import sqlite3
import os

app = Flask(__name__)

DB_NAME = "inventory.db"

# Database initialization
def init_db():
    with sqlite3.connect(DB_NAME) as conn:
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS inventory (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        vendor_code TEXT,
                        description TEXT,
                        quantity INTEGER,
                        price REAL
                    )''')
        conn.commit()

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/inventory')
def inventory():
    with sqlite3.connect(DB_NAME) as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM inventory")
        items = c.fetchall()
    return render_template('inventory.html', items=items)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        vendor = request.form['vendor']
        desc = request.form['description']
        qty = request.form['quantity']
        price = request.form['price']
        with sqlite3.connect(DB_NAME) as conn:
            c = conn.cursor()
            c.execute("INSERT INTO inventory (vendor_code, description, quantity, price) VALUES (?, ?, ?, ?)",
                      (vendor, desc, qty, price))
            conn.commit()
        return redirect(url_for('inventory'))
    return render_template('add.html')

# Only used if running locally (not used by Gunicorn)
if __name__ == "__main__":
    init_db()
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)

# Always init DB (even when running with Gunicorn)
init_db()
