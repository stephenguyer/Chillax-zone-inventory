from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)
DATABASE = 'inventory_app.db'

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/inventory')
def inventory():
    conn = get_db_connection()
    items = conn.execute('SELECT * FROM inventory').fetchall()
    conn.close()
    return render_template('inventory.html', items=items)

@app.route('/vendor/<vendor_code>')
def vendor_inventory(vendor_code):
    conn = get_db_connection()
    items = conn.execute('SELECT * FROM inventory WHERE vendor_code = ?', (vendor_code,)).fetchall()
    conn.close()
    return render_template('vendor_inventory.html', vendor_code=vendor_code, items=items)

@app.route('/add', methods=['GET', 'POST'])
def add_item():
    if request.method == 'POST':
        item_code = request.form['item_code']
        item_description = request.form['item_description']
        vendor_code = request.form['vendor_code']
        quantity = int(request.form['quantity'])
        retail_price = float(request.form['retail_price'])
        notes = request.form['notes']
        conn = get_db_connection()
        conn.execute('INSERT INTO inventory (item_code, item_description, vendor_code, quantity, retail_price, notes) VALUES (?, ?, ?, ?, ?, ?)',
                     (item_code, item_description, vendor_code, quantity, retail_price, notes))
        conn.commit()
        conn.close()
        return redirect(url_for('inventory'))
    return render_template('add_item.html')

@app.route('/delete/<int:item_id>')
def delete_item(item_id):
    conn = get_db_connection()
    conn.execute('DELETE FROM inventory WHERE id = ?', (item_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('inventory'))

if __name__ == '__main__':
    app.run(debug=True)
